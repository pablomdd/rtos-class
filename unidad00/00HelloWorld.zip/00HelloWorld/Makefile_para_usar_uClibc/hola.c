/** hola.c */
int printf(char *,...);

int main(){
 printf("Hola Mundo C!\n");
 return 20; 
}

